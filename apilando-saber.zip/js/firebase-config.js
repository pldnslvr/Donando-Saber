import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  collection,
  query,
  where,
  limit,
  getDocs,
  increment
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
 
// ==========================================
// 1. CONFIGURACIÓN
// ==========================================
// La apiKey de Firebase es pública por diseño; protégela con reglas de
// Firestore, restricción de dominios y App Check.
const firebaseConfig = {
  apiKey: "AIzaSyD7VyXjg4L1yzo-NguQ4k8aglkd9r2Iy3Q",
  authDomain: "api-lando-saber-b4d78.firebaseapp.com",
  projectId: "api-lando-saber-b4d78",
  storageBucket: "api-lando-saber-b4d78.firebasestorage.app",
  messagingSenderId: "584298926368",
  appId: "1:584298926368:web:9802c757630728a5eb0745",
  measurementId: "G-HCQ9G5QEXP"
};
 
// NUNCA pongas la clave de Gemini en el navegador. Crea una Cloud Function
// (o similar) que guarde la clave y reciba { prompt } devolviendo el JSON del cuento.
// Mientras esté vacío se usan los cuentos locales.
const STORY_ENDPOINT = "";
 
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
 
// ==========================================
// 2. UTILIDADES Y ELEMENTOS DEL DOM
// ==========================================
const $ = (id) => document.getElementById(id);
 
const authSection = $("auth-section");
const appSection = $("app-section");
const mainView = $("main-view");
const profileView = $("profile-view");
const authForm = $("auth-form");
const emailInput = $("email");
const passwordInput = $("password");
const authTitle = $("auth-title");
const btnSubmit = $("btn-submit");
const btnToggleAuth = $("btn-toggle-auth");
const btnLogout = $("btn-logout");
const authMessage = $("auth-message");
 
const headerPfp = $("header-pfp");
const profilePfp = $("profile-pfp");
const btnCloseProfile = $("btn-close-profile");
const welcomeDisplay = $("welcome-display");
const profileUsernameDisplay = $("profile-username-display");
const profileEmailDisplay = $("profile-email-display");
const profilePoints = $("profile-points");
const profileStreak = $("profile-streak");
const usernameInput = $("username-input");
const displayNameInput = $("display-name-input");
const btnSaveProfile = $("btn-save-profile");
const profileMessage = $("profile-message");
const pfpOptions = document.querySelectorAll(".pfp-option");
 
const PFP_CLASSES = ["pfp-default", "pfp-style1", "pfp-style2", "pfp-style3", "pfp-style4"];
const ACTIVITIES = ["cuentos", "mates", "ecologia", "ingles"];
 
let isLoginMode = true;
let currentUser = null;
let currentPoints = 0;
let selectedPfpClass = "pfp-default";
let currentAgeGroup = "6-7";
let currentStoryData = null;
let ecoDoneToday = false;
let chatRewards = 0;
 
function getToday() {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  return local.toISOString().split("T")[0];
}
 
function shuffle(array) {
  const a = [...array];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
 
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
 
function setMessage(el, text, type = "") {
  el.textContent = text;
  el.className = "auth-message" + (type ? " " + type : "");
  el.style.color = "";
}
 
// ==========================================
// 3. AUTENTICACIÓN
// ==========================================
btnToggleAuth?.addEventListener("click", () => {
  isLoginMode = !isLoginMode;
  setMessage(authMessage, "");
 
  if (isLoginMode) {
    authTitle.textContent = "Iniciar Sesión";
    btnSubmit.textContent = "Ingresar";
    btnToggleAuth.textContent = "¿No tienes cuenta? Regístrate";
  } else {
    authTitle.textContent = "Crear Cuenta";
    btnSubmit.textContent = "Registrarse";
    btnToggleAuth.textContent = "¿Ya tienes cuenta? Inicia Sesión";
  }
});
 
authForm?.addEventListener("submit", async (e) => {
  e.preventDefault();
 
  const email = emailInput.value.trim();
  const password = passwordInput.value;
 
  setMessage(authMessage, "");
  btnSubmit.disabled = true;
 
  try {
    if (isLoginMode) {
      await signInWithEmailAndPassword(auth, email, password);
    } else {
      // El documento del usuario lo crea loadUserData (evita la condición
      // de carrera con onAuthStateChanged).
      await createUserWithEmailAndPassword(auth, email, password);
    }
  } catch (error) {
    setMessage(authMessage, getAuthError(error), "error");
  } finally {
    btnSubmit.disabled = false;
  }
});
 
function getAuthError(error) {
  const messages = {
    "auth/invalid-credential": "Correo o contraseña incorrectos.",
    "auth/user-not-found": "Correo o contraseña incorrectos.",
    "auth/wrong-password": "Correo o contraseña incorrectos.",
    "auth/email-already-in-use": "Este correo ya tiene una cuenta.",
    "auth/weak-password": "La contraseña debe tener al menos 6 caracteres.",
    "auth/invalid-email": "El correo electrónico no es válido.",
    "auth/too-many-requests": "Demasiados intentos. Espera un momento e inténtalo otra vez.",
    "auth/network-request-failed": "Revisa tu conexión a internet."
  };
  return messages[error.code] || "No se pudo completar la operación. Inténtalo de nuevo.";
}
 
btnLogout?.addEventListener("click", () => signOut(auth));
 
// ==========================================
// 4. NAVEGACIÓN ENTRE VISTAS
// ==========================================
function hideAllViews() {
  mainView?.classList.add("hidden");
  profileView?.classList.add("hidden");
  ACTIVITIES.forEach((name) => $("activity-" + name)?.classList.add("hidden"));
}
 
function showMain() {
  hideAllViews();
  mainView?.classList.remove("hidden");
}
 
function openActivity(activity) {
  if (!ACTIVITIES.includes(activity)) return;
  hideAllViews();
  $("activity-" + activity)?.classList.remove("hidden");
 
  if (activity === "mates") generateMathProblem();
  if (activity === "ingles") loadEnglishQuestion();
}
 
function closeActivity() {
  showMain();
}
 
function setAgeGroup(age) {
  currentAgeGroup = age;
  document.querySelectorAll(".btn-age").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.age === age);
  });
 
  const mathSection = $("activity-mates");
  if (mathSection && !mathSection.classList.contains("hidden")) {
    generateMathProblem();
  }
}
 
// ==========================================
// 5. PERFIL
// ==========================================
headerPfp?.addEventListener("click", () => {
  hideAllViews();
  profileView.classList.remove("hidden");
});
 
btnCloseProfile?.addEventListener("click", showMain);
 
pfpOptions.forEach((option) => {
  option.addEventListener("click", () => {
    pfpOptions.forEach((item) => item.classList.remove("active"));
    option.classList.add("active");
    selectedPfpClass = option.dataset.pfp;
    updatePfpClasses(selectedPfpClass);
  });
});
 
function updatePfpClasses(newClass) {
  if (!PFP_CLASSES.includes(newClass)) newClass = "pfp-default";
  [headerPfp, profilePfp].forEach((el) => {
    if (!el) return;
    el.classList.remove(...PFP_CLASSES);
    el.classList.add(newClass);
  });
}
 
btnSaveProfile?.addEventListener("click", async () => {
  if (!currentUser) return;
 
  const username = usernameInput.value.trim().toLowerCase().replace(/^@/, "");
  const displayName = displayNameInput.value.trim().slice(0, 30);
 
  setMessage(profileMessage, "");
 
  if (!/^[a-z0-9_]{3,20}$/.test(username)) {
    setMessage(profileMessage, "El usuario debe tener 3-20 caracteres: letras, números o guion bajo.", "error");
    return;
  }
 
  btnSaveProfile.disabled = true;
  try {
    const snapshot = await getDocs(query(collection(db, "users"), where("username", "==", username)));
    const isTaken = snapshot.docs.some((item) => item.id !== currentUser.uid);
 
    if (isTaken) {
      setMessage(profileMessage, `El usuario @${username} ya está ocupado.`, "error");
      return;
    }
 
    await setDoc(
      doc(db, "users", currentUser.uid),
      { username, displayName: displayName || "Estudiante", pfpClass: selectedPfpClass },
      { merge: true }
    );
 
    profileUsernameDisplay.textContent = "@" + username;
    welcomeDisplay.textContent = displayName || username;
    usernameInput.value = "@" + username;
 
    setMessage(profileMessage, "¡Perfil actualizado correctamente!");
    profileMessage.style.color = "#2b3a33";
  } catch (error) {
    console.error(error);
    setMessage(profileMessage, "No se pudo guardar el perfil. Inténtalo de nuevo.", "error");
  } finally {
    btnSaveProfile.disabled = false;
  }
});
 
// ==========================================
// 6. CARGA DE DATOS Y RACHA
// ==========================================
async function loadUserData(user) {
  currentUser = user;
  currentPoints = 0;
  ecoDoneToday = false;
  chatRewards = 0;
 
  const userRef = doc(db, "users", user.uid);
  let snapshot = await getDoc(userRef);
 
  if (!snapshot.exists()) {
    await setDoc(userRef, {
      email: user.email,
      username: "user_" + user.uid.substring(0, 5),
      displayName: "Nuevo Estudiante 🌟",
      pfpClass: "pfp-default",
      points: 0,
      streak: 1,
      lastLoginDate: getToday()
    });
    snapshot = await getDoc(userRef);
  }
 
  const data = snapshot.data();
  const today = getToday();
  const lastLogin = data.lastLoginDate;
  let streak = Number(data.streak) || 1;
 
  if (lastLogin && lastLogin !== today) {
    const diff = Math.round(
      (new Date(today + "T12:00:00") - new Date(lastLogin + "T12:00:00")) / 86400000
    );
    streak = diff === 1 ? streak + 1 : 1;
  }
 
  if (lastLogin !== today) {
    await setDoc(userRef, { streak, lastLoginDate: today }, { merge: true });
  }
 
  currentPoints = Number(data.points) || 0;
  ecoDoneToday = data.lastEcoDate === today;
 
  profileEmailDisplay.textContent = data.email || user.email;
  usernameInput.value = "@" + (data.username || "");
  profileUsernameDisplay.textContent = "@" + (data.username || "usuario");
  displayNameInput.value = data.displayName || "";
  welcomeDisplay.textContent = data.displayName || data.username || "estudiante";
  profilePoints.textContent = currentPoints;
  profileStreak.textContent = streak;
 
  selectedPfpClass = PFP_CLASSES.includes(data.pfpClass) ? data.pfpClass : "pfp-default";
  updatePfpClasses(selectedPfpClass);
  pfpOptions.forEach((option) => {
    option.classList.toggle("active", option.dataset.pfp === selectedPfpClass);
  });
 
  if (ecoDoneToday) {
    $("eco-task-desc").textContent = "¡Ya completaste este reto hoy! 🌱";
  }
}
 
onAuthStateChanged(auth, async (user) => {
  if (user) {
    authSection.classList.add("hidden");
    appSection.classList.remove("hidden");
    showMain();
    try {
      await loadUserData(user);
      loadAnnouncements();
    } catch (error) {
      console.error("Error al cargar perfil:", error);
    }
  } else {
    currentUser = null;
    currentPoints = 0;
    authForm?.reset();
    authSection.classList.remove("hidden");
    appSection.classList.add("hidden");
    $("chatbot-modal")?.classList.add("hidden");
  }
});
 
// ==========================================
// 7. PUNTOS (atómicos, sin leer antes de escribir)
// ==========================================
async function addPoints(points, extraFields = {}) {
  if (!currentUser) return;
  try {
    await setDoc(
      doc(db, "users", currentUser.uid),
      { points: increment(points), ...extraFields },
      { merge: true }
    );
    currentPoints += points;
    profilePoints.textContent = currentPoints;
  } catch (err) {
    console.error("Error guardando puntos:", err);
  }
}
 
// ==========================================
// 8. CUENTOS
// ==========================================
const localStoriesByAge = {
  "6-7": [{
    title: "La semillita valiente",
    body: "Luna encontró una semilla pequeña y brillante. La sembró cerca del río y cada mañana le llevaba agua limpia.\n\nCon los días, la semillita brotó y se convirtió en un gran árbol. Los pajaritos del bosque vinieron a cantar entre sus ramas y Luna comprendió que cuidar a la naturaleza llena el corazón de alegría.",
    question: "¿Qué usó Luna para cuidar la semilla?",
    options: ["Agua limpia", "Piedras", "Jugos dulces"],
    correct: 0
  }],
  "8-9": [{
    title: "El misterio del parque limpio",
    body: "En el vecindario de Mateo, el parque local amanecía lleno de envoltorios y botellas de plástico tras los fines de semana. Mateo y su amiga Sofía decidieron investigar de dónde venía la basura y organizaron a los niños del barrio.\n\nJuntos colocaron contenedores de reciclaje de colores vibrantes y carteles explicativos. Gracias a su perseverancia, los vecinos aprendieron a clasificar los residuos y el parque volvió a ser un lugar verde y seguro.",
    question: "¿Qué solución propusieron Mateo y Sofía para resolver el problema?",
    options: ["Instalar contenedores de reciclaje y carteles", "Prohibir la entrada al parque", "Esperar a que otros limpiaran"],
    correct: 0
  }],
  "10-12": [{
    title: "El Guardián de la Colmena",
    body: "Durante un taller escolar sobre biodiversidad, Lucas descubrió que la población de abejas en su región estaba disminuyendo debido al uso excesivo de pesticidas e insecticidas. Entendió que, sin estos polinizadores, muchos alimentos y plantas silvestres desaparecerían para siempre.\n\nDecidido a actuar, Lucas diseñó un proyecto con su grupo de ciencias para construir un jardín con flores autóctonas y sin químicos en el patio del colegio. El proyecto fue un éxito e inspiró a otras escuelas de la ciudad a crear corredores verdes ecológicos.",
    question: "¿Cuál fue el impacto principal de la iniciativa ecológica de Lucas?",
    options: ["Inspiró a otras escuelas a crear corredores verdes sin químicos", "Consiguió que se prohibieran todas las granjas", "Descubrió una nueva especie de flor exótica"],
    correct: 0
  }]
};
 
function getStoryPromptByAge(ageGroup) {
  const levels = {
    "6-7": `
      - PÚBLICO: Niños de 6 a 7 años.
      - EXTENSIÓN: 2 a 3 párrafos medianos (120-160 palabras en total).
      - ESTILO: Lenguaje muy accesible, frases directas, tono cálido y tierno.
      - TEMA: Cuidado del agua, plantas, animales o la amistad.
      - PREGUNTA: Directa y sencilla sobre lo ocurrido.`,
    "8-9": `
      - PÚBLICO: Niños de 8 a 9 años.
      - EXTENSIÓN: 3 a 4 párrafos (200-260 palabras en total).
      - ESTILO: Vocabulario enriquecido, un problema a resolver, trabajo en equipo.
      - TEMA: Reciclaje, preservación de hábitats o energía limpia.
      - PREGUNTA: Comprensión de causa y efecto.`,
    "10-12": `
      - PÚBLICO: Niños de 10 a 12 años.
      - EXTENSIÓN: 4 a 5 párrafos (300-380 palabras en total).
      - ESTILO: Lenguaje fluido y descriptivo con conceptos ecológicos básicos.
      - TEMA: Soluciones tecnológicas o comunitarias al cambio climático o protección de especies.
      - PREGUNTA: Pensamiento crítico sobre la lección principal.`
  };
 
  return `Crea un cuento infantil educativo, apropiado para niños, con estos requisitos:
  ${levels[ageGroup] || levels["6-7"]}
 
  REGLA OBLIGATORIA: Responde ÚNICAMENTE con un objeto JSON válido, sin Markdown ni texto fuera del JSON. Formato exacto:
  {
    "title": "Título llamativo del cuento",
    "body": "Texto completo del cuento, párrafos separados por \\n\\n.",
    "question": "Pregunta de comprensión lectora acorde al nivel",
    "options": ["Opción correcta", "Opción incorrecta 1", "Opción incorrecta 2"],
    "correct": 0
  }`;
}
 
function isValidStory(s) {
  return (
    s &&
    typeof s.title === "string" &&
    typeof s.body === "string" &&
    typeof s.question === "string" &&
    Array.isArray(s.options) &&
    s.options.length >= 2 &&
    s.options.every((o) => typeof o === "string") &&
    Number.isInteger(s.correct) &&
    s.correct >= 0 &&
    s.correct < s.options.length
  );
}
 
async function fetchStoryFromAI(ageGroup) {
  if (!STORY_ENDPOINT) throw new Error("Sin endpoint de IA configurado.");
 
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const res = await fetch(STORY_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: getStoryPromptByAge(ageGroup) }),
      signal: controller.signal
    });
    if (!res.ok) throw new Error("Error " + res.status);
    const story = await res.json();
    if (!isValidStory(story)) throw new Error("Cuento con formato inválido.");
    return story;
  } finally {
    clearTimeout(timer);
  }
}
 
$("btn-fetch-story")?.addEventListener("click", async () => {
  const content = $("story-content");
  const title = $("story-title");
  const body = $("story-body");
  const question = $("quiz-question");
  const optionsDiv = $("quiz-options");
  const button = $("btn-fetch-story");
 
  content.classList.remove("hidden");
  title.textContent = "✨ Creando tu cuento...";
  body.textContent = "Por favor espera un momento.";
  question.textContent = "";
  optionsDiv.innerHTML = "";
  button.disabled = true;
 
  let story;
  try {
    story = await fetchStoryFromAI(currentAgeGroup);
  } catch (err) {
    console.log("Usando cuento local de respaldo:", err.message);
    const list = localStoriesByAge[currentAgeGroup] || localStoriesByAge["6-7"];
    story = list[Math.floor(Math.random() * list.length)];
  } finally {
    button.disabled = false;
  }
 
  const correctText = story.options[story.correct];
  const options = shuffle(story.options);
  currentStoryData = { ...story, options, correct: options.indexOf(correctText) };
 
  title.textContent = currentStoryData.title;
  body.style.whiteSpace = "pre-line";
  body.textContent = currentStoryData.body;
  question.textContent = "❓ " + currentStoryData.question;
 
  options.forEach((opt, index) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn btn-secondary";
    btn.style.margin = "4px";
    btn.textContent = opt;
    btn.addEventListener("click", () => checkStoryQuiz(index));
    optionsDiv.appendChild(btn);
  });
});
 
function checkStoryQuiz(index) {
  document.querySelectorAll("#quiz-options button").forEach((b) => (b.disabled = true));
  const question = $("quiz-question");
 
  if (index === currentStoryData.correct) {
    question.textContent = "¡Correcto! Ganaste +10 Puntos ⭐";
    addPoints(10);
  } else {
    question.textContent =
      "Casi. La respuesta correcta era: " + currentStoryData.options[currentStoryData.correct];
  }
}
 
// ==========================================
// 9. MATEMÁTICAS
// ==========================================
let mathAnswer = 0;
let mathLocked = false;
 
function generateMathProblem() {
  const problemEl = $("math-problem");
  const inputEl = $("math-user-answer");
  const feedbackEl = $("math-feedback");
  if (!problemEl || !inputEl || !feedbackEl) return;
 
  mathLocked = false;
  inputEl.value = "";
  feedbackEl.textContent = "";
 
  let a, b, op;
 
  if (currentAgeGroup === "6-7") {
    if (Math.random() > 0.5) {
      a = randInt(1, 10); b = randInt(1, 10); op = "+"; mathAnswer = a + b;
    } else {
      a = randInt(5, 15); b = randInt(1, a); op = "-"; mathAnswer = a - b;
    }
  } else if (currentAgeGroup === "8-9") {
    const type = randInt(0, 2);
    if (type === 0) { a = randInt(2, 9); b = randInt(2, 10); op = "×"; mathAnswer = a * b; }
    else if (type === 1) { a = randInt(10, 49); b = randInt(10, 49); op = "+"; mathAnswer = a + b; }
    else { a = randInt(20, 69); b = randInt(5, 24); op = "-"; mathAnswer = a - b; }
  } else {
    if (Math.random() > 0.5) {
      b = randInt(2, 9);
      mathAnswer = randInt(3, 14);
      a = b * mathAnswer;
      op = "÷";
    } else {
      a = randInt(6, 20); b = randInt(4, 15); op = "×"; mathAnswer = a * b;
    }
  }
 
  problemEl.textContent = `¿Cuánto es ${a} ${op} ${b}?`;
}
 
function checkMathAnswer() {
  if (mathLocked) return; // evita sumar puntos varias veces por el mismo problema
 
  const input = $("math-user-answer");
  const feedback = $("math-feedback");
 
  if (!input.value.trim()) {
    feedback.textContent = "Escribe una respuesta primero.";
    return;
  }
 
  if (Number(input.value) === mathAnswer) {
    mathLocked = true;
    feedback.textContent = "¡Excelente! +10 Puntos 🎉";
    addPoints(10);
    setTimeout(generateMathProblem, 1200);
  } else {
    feedback.textContent = "Incorrecto, intenta de nuevo.";
  }
}
 
$("math-user-answer")?.addEventListener("keydown", (e) => {
  if (e.key === "Enter") checkMathAnswer();
});
 
// ==========================================
// 10. RETOS ECOLÓGICOS (un reto por día, guardado en Firestore)
// ==========================================
async function completeEcoTask() {
  const desc = $("eco-task-desc");
  if (ecoDoneToday) {
    desc.textContent = "¡Ya completaste este reto hoy! 🌱";
    return;
  }
  ecoDoneToday = true;
  await addPoints(15, { lastEcoDate: getToday() });
  desc.textContent = "¡Reto cumplido! Gracias por cuidar el planeta (+15 Pts) 🌎";
}
 
// ==========================================
// 11. INGLÉS
// ==========================================
const englishQuestions = [
  { q: "How do you say 'Manzana' in English?", options: ["Apple", "Banana", "Grape"], correct: 0 },
  { q: "Complete the sentence: 'She ___ my best friend.'", options: ["am", "is", "are"], correct: 1 },
  { q: "What is the opposite of 'Big'?", options: ["Fast", "Small", "Tall"], correct: 1 },
  { q: "Select the correct plural: 'One cat, two ___'", options: ["cats", "cates", "catss"], correct: 0 },
  { q: "How do you say 'Perro' in English?", options: ["Cat", "Dog", "Bird"], correct: 1 },
  { q: "Complete the sentence: 'They ___ playing soccer.'", options: ["is", "am", "are"], correct: 2 },
  { q: "What color is the sky on a sunny day?", options: ["Blue", "Green", "Red"], correct: 0 },
  { q: "Which word means 'Escuela'?", options: ["House", "School", "Store"], correct: 1 }
];
 
let englishOrder = [];
let englishPos = 0;
let englishLocked = false;
 
function loadEnglishQuestion() {
  if (englishPos >= englishOrder.length) {
    englishOrder = shuffle(englishQuestions);
    englishPos = 0;
  }
  englishLocked = false;
 
  const item = englishOrder[englishPos];
  $("english-question").textContent = item.q;
  const feedback = $("english-feedback");
  feedback.textContent = "";
  feedback.style.color = "";
 
  const optionsDiv = $("english-options");
  optionsDiv.innerHTML = "";
 
  item.options.forEach((opt, idx) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn btn-secondary";
    btn.style.margin = "4px";
    btn.textContent = opt;
    btn.addEventListener("click", () => checkEnglishAnswer(idx));
    optionsDiv.appendChild(btn);
  });
}
 
function checkEnglishAnswer(selected) {
  if (englishLocked) return;
  const item = englishOrder[englishPos];
  const feedback = $("english-feedback");
 
  if (selected === item.correct) {
    englishLocked = true;
    feedback.style.color = "#81c784";
    feedback.textContent = "¡Correct! Great job! +10 Points ⭐";
    addPoints(10);
    setTimeout(() => {
      englishPos++;
      loadEnglishQuestion();
    }, 1500);
  } else {
    feedback.style.color = "#e58282";
    feedback.textContent = "Try again!";
  }
}
 
// ==========================================
// 12. TABLÓN DE ANUNCIOS (sin innerHTML → sin XSS)
// ==========================================
async function loadAnnouncements() {
  const list = $("announcements-list");
  if (!list) return;
 
  try {
    const snap = await getDocs(query(collection(db, "announcements"), limit(10)));
    if (snap.empty) return;
 
    list.innerHTML = "";
    snap.forEach((docSnap) => {
      const data = docSnap.data();
 
      const item = document.createElement("div");
      item.className = "announcement-item";
 
      const meta = document.createElement("div");
      meta.className = "announcement-meta";
 
      const tag = document.createElement("span");
      tag.className = "announcement-tag tag-taller";
      tag.textContent = data.tag || "📌 Aviso";
 
      const date = document.createElement("span");
      date.className = "announcement-date";
      date.textContent = data.date || "Reciente";
 
      const text = document.createElement("p");
      text.className = "announcement-text";
      text.textContent = data.message || "";
 
      meta.append(tag, date);
      item.append(meta, text);
      list.appendChild(item);
    });
  } catch (error) {
    console.log("Mostrando anuncio local:", error.message);
  }
}
 
// ==========================================
// 13. CHATBOT (Wikipedia con búsqueda aproximada)
// ==========================================
const chatForm = $("chat-form");
const chatInput = $("chat-input");
const chatMessages = $("chat-messages");
const MAX_CHAT_REWARDS = 5; // puntos por sesión, evita abusar del +5
 
function appendChatMessage(text, sender) {
  const msg = document.createElement("div");
  msg.className = `chat-msg ${sender === "user" ? "user-msg" : "bot-msg"}`;
  msg.textContent = text;
  chatMessages.appendChild(msg);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return msg;
}
 
async function searchWikipedia(term) {
  const search = await fetch(
    `https://es.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(term)}&limit=1&format=json&origin=*`
  );
  if (!search.ok) throw new Error("Búsqueda fallida");
  const [, titles] = await search.json();
  if (!titles?.length) return null;
 
  const res = await fetch(
    `https://es.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(titles[0])}`
  );
  if (!res.ok) return null;
  const data = await res.json();
  if (data.type === "disambiguation" || !data.extract) return null;
  return data;
}
 
chatForm?.addEventListener("submit", async (e) => {
  e.preventDefault();
 
  const queryText = chatInput.value.trim().slice(0, 100);
  if (!queryText) return;
 
  appendChatMessage(queryText, "user");
  chatInput.value = "";
 
  const loadingMsg = appendChatMessage("🔍 Buscando información...", "bot");
 
  try {
    const data = await searchWikipedia(queryText);
    if (data) {
      loadingMsg.textContent = `📚 ${data.title}: ${data.extract}`;
      if (chatRewards < MAX_CHAT_REWARDS) {
        chatRewards++;
        addPoints(5);
      }
    } else {
      loadingMsg.textContent = '🤖 No encontré detalles sobre ese tema. ¡Prueba con otra palabra clave!';
    }
  } catch (error) {
    loadingMsg.textContent =
      '🤖 No pude conectarme. Revisa tu internet o prueba con: "Sistema solar", "Dinosaurios" o "Fotosíntesis".';
  }
 
  chatMessages.scrollTop = chatMessages.scrollHeight;
});
 
function toggleChatbotModal() {
  $("chatbot-modal")?.classList.toggle("hidden");
}
 
// ==========================================
// 14. MODO OSCURO
// ==========================================
const btnThemeToggle = $("btn-theme-toggle");
const themeIcon = $("theme-icon");
 
function safeStorage(action, key, value) {
  try {
    return action === "get" ? localStorage.getItem(key) : localStorage.setItem(key, value);
  } catch {
    return null;
  }
}
 
function applyTheme(isDark) {
  document.body.classList.toggle("dark-mode", isDark);
  if (themeIcon) themeIcon.textContent = isDark ? "☀️" : "🌙";
}
 
applyTheme(safeStorage("get", "app-theme") === "dark");
 
btnThemeToggle?.addEventListener("click", () => {
  const isDark = !document.body.classList.contains("dark-mode");
  applyTheme(isDark);
  safeStorage("set", "app-theme", isDark ? "dark" : "light");
});
 
// ==========================================
// 15. REGISTRO GLOBAL (para los onclick del HTML)
// ==========================================
window.openActivity = openActivity;
window.closeActivity = closeActivity;
window.setAgeGroup = setAgeGroup;
window.checkMathAnswer = checkMathAnswer;
window.completeEcoTask = completeEcoTask;
window.toggleChatbotModal = toggleChatbotModal;
 